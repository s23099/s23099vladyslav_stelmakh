trait Maybe[A] {}
