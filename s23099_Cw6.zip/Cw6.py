import riak

Client = riak.RiakClient(pb_port=8087, protocol='pbc')

cl_bucket = myClient.bucket('23099')

andrian = {'user_name': 'andrian',
           'full_name': 'andrian Manager',
           'email': 'andrian.manager@riak.com'}

key1 = cl_bucket.new('one', data=andrian)
key1.store()
get1 = cl_bucket.get('one')
print(get1.data)
get1.data["full_name"] = "Pity"
get1.store()
get1 = cl_bucket.get('one').data
print(get1)
get1 = cl_bucket.get('one')
get1.delete()
get1 = cl_bucket.get('one')
print(get1.data)